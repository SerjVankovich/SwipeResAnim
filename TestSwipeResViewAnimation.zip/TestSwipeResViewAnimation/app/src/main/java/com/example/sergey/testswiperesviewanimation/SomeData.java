package com.example.sergey.testswiperesviewanimation;

/**
 * Created by sergey on 29.12.17.
 */

class SomeData {
    private String title;

    public SomeData(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
