package com.example.sergey.testswiperesviewanimation;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.chauthai.swipereveallayout.SwipeRevealLayout;
import com.chauthai.swipereveallayout.ViewBinderHelper;
import com.yarolegovich.slidingrootnav.SlidingRootNav;
import com.yarolegovich.slidingrootnav.SlidingRootNavBuilder;
import com.yarolegovich.slidingrootnav.SlidingRootNavLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SlidingRootNav, NavigationView.OnNavigationItemSelectedListener {
    RecyclerView rv;
    ResAdapter adapter;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawerLayout = findViewById(R.id.drawerLayout);
        ActionBarDrawerToggle toggle =new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.menu);
        navigationView.setNavigationItemSelectedListener(this);

        adapter = new ResAdapter((mockData()));

        rv = findViewById(R.id.rv);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        new SlidingRootNavBuilder(this).withMenuLayout(R.layout.menu).inject();




    }




    List<SomeData> mockData() {
        List<SomeData> list = new ArrayList<>();

        for (int i = 0; i < 50; i++) {
            SomeData sd = new SomeData("CardView" + (i + 1));
            list.add(sd);

        }
        return list;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if(adapter != null) {
            adapter.saveStates(outState);
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if(adapter != null) {
            adapter.restoreStates(savedInstanceState);
        }
    }

    @Override
    public boolean isMenuClosed() {

        return true;
    }

    @Override
    public boolean isMenuOpened() {

        return true;
    }

    @Override
    public boolean isMenuLocked() {
        return false;
    }

    @Override
    public void closeMenu() {

    }

    @Override
    public void closeMenu(boolean animated) {

    }

    @Override
    public void openMenu() {
        getActionBar().hide();
    }

    @Override
    public void openMenu(boolean animated) {

    }

    @Override
    public void setMenuLocked(boolean locked) {

    }

    @Override
    public SlidingRootNavLayout getLayout() {
        return null;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        return false;
    }
}

class ResAdapter extends RecyclerView.Adapter<ResAdapter.ViewHolder> {
    List<SomeData> dataList;
    private final ViewBinderHelper vhelper = new ViewBinderHelper();

    public ResAdapter(List<SomeData> dataList) {
        this.dataList = dataList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view, parent,false);

        ViewHolder vh = new ViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.title.setText(dataList.get(position).getTitle());
        vhelper.bind(holder.svl, dataList.get(position).getTitle());
        vhelper.setOpenOnlyOne(true);

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        SwipeRevealLayout svl;
        TextView title;

        public ViewHolder(View itemView) {
            super(itemView);
            svl = itemView.findViewById(R.id.card_view);
            title = itemView.findViewById(R.id.title);

        }
    }

    public void deleteCardView(int position) {
        this.dataList.remove(position);
        this.notifyItemRemoved(position);
    }
    public void moveCardView(int oldPosition, int newPosition) {
        SomeData data = this.dataList.get(oldPosition);
        this.dataList.remove(oldPosition);
        this.dataList.add(newPosition, data);
        this.notifyItemMoved(oldPosition, newPosition);
    }
    public void saveStates(Bundle outState) {
        vhelper.saveStates(outState);
    }
    public void restoreStates(Bundle inState) {
        vhelper.restoreStates(inState);
    }
}


