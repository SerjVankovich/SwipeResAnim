package com.example.sergey.myapplication.DataBase;

/**
 * Created by sergey on 07.01.2018.
 */

public class DBCard {
    public String title;
    public String content;
    public int absoluteID;

    public DBCard(String title, String content) {
        this.title = title;
        this.content = content;
    }

}
