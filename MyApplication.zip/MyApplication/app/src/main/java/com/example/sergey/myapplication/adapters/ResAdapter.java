package com.example.sergey.myapplication.adapters;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.chauthai.swipereveallayout.SwipeRevealLayout;
import com.chauthai.swipereveallayout.ViewBinderHelper;
import com.example.sergey.myapplication.DataBase.DBCard;
import com.example.sergey.myapplication.DataBase.DataBaseHelper;
import com.example.sergey.myapplication.R;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;



public class ResAdapter extends RecyclerView.Adapter<ResAdapter.ViewHolder> {
    List<DBCard> main_array;
    DataBaseHelper dbHelper;
    Context context;
    private final ViewBinderHelper vhelper;

    public ResAdapter(Context context) {
        this.context = context;
        this.main_array = getMain_array();
        vhelper = new ViewBinderHelper();


    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        SwipeRevealLayout cardView;
        TextView title;
        TextView content;
        Button delete;
        public ViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.Title);
            content = itemView.findViewById(R.id.content);
            cardView = itemView.findViewById(R.id.card_view);
            delete = itemView.findViewById(R.id.del);


        }
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view, parent, false);
        ViewHolder vh = new ViewHolder(view);
        return vh;
    }



    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        holder.title.setText(main_array.get(position).title);
        holder.content.setText(main_array.get(position).content);
        vhelper.bind(holder.cardView, main_array.get(position).toString());
        vhelper.setOpenOnlyOne(true);
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHelper = new DataBaseHelper(context);
                SQLiteDatabase database = dbHelper.getWritableDatabase();
                database.delete(DataBaseHelper.TABLE_CONTACTS, DataBaseHelper.KEY_ID + "= " +  main_array.get(position).absoluteID, null);

                deleteCardView(position);
                database.close();
            }
        });

    }
    public List<DBCard> getMain_array (){
        dbHelper = new DataBaseHelper(context);

        List<DBCard> list = new ArrayList<>();
        SQLiteDatabase database = this.dbHelper.getReadableDatabase();


        Cursor cursor = database.query(DataBaseHelper.TABLE_CONTACTS, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex(DataBaseHelper.KEY_TITLE);
            int contentIndex = cursor.getColumnIndex(DataBaseHelper.KEY_TEXT);
            int idIndex = cursor.getColumnIndex(DataBaseHelper.KEY_ID);

            do {
                Log.d("All content", "id: " + cursor.getInt(idIndex)+ "Title: " + cursor.getString(nameIndex) + ", Content: " + cursor.getString(contentIndex));
                DBCard card = new DBCard(cursor.getString(nameIndex), cursor.getString(contentIndex));
                card.absoluteID = cursor.getInt(idIndex);


                list.add(card);
            } while (cursor.moveToNext());
        }
        cursor.close();
        dbHelper.close();
        return list;


    }


    @Override
    public int getItemCount() {
        return main_array.size();
    }

    public void saveStates(Bundle outState){
        vhelper.saveStates(outState);
    }
    public void restoreStates(Bundle inState) {
        vhelper.restoreStates(inState);
    }
    public void deleteCardView(int position){
        main_array.remove(position);
        notifyItemRemoved(position);
    }
}
