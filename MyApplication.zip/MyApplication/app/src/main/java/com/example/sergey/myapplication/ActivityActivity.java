package com.example.sergey.myapplication;

import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.sergey.myapplication.DataBase.DataBaseHelper;
import com.example.sergey.myapplication.adapters.ResAdapter;

public class ActivityActivity extends AppCompatActivity {
    DataBaseHelper dataBaseHelper;
    SQLiteDatabase database;
    ResAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        adapter = new ResAdapter(getApplicationContext());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if(adapter!= null) {
            adapter.saveStates(outState);
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if(adapter != null) {
            adapter.restoreStates(savedInstanceState);
        }
    }
}
