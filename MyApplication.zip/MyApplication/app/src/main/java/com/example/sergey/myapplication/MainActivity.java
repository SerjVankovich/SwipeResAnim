package com.example.sergey.myapplication;


import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PorterDuff;

import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.sergey.myapplication.DataBase.DBCard;
import com.example.sergey.myapplication.DataBase.DataBaseHelper;
import com.example.sergey.myapplication.fragments.FragmentKredit;
import com.yarolegovich.slidingrootnav.SlidingRootNav;
import com.yarolegovich.slidingrootnav.SlidingRootNavBuilder;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, NavigationView.OnNavigationItemSelectedListener{
    EditText name, email;
    Button add, read, clear;
    TextView tv;
    Toolbar toolbar;

    DataBaseHelper dbHelper;
    FragmentKredit fkredit;

    NavigationView navigationView;
    SlidingRootNav slidingBuilder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.tv);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        name = findViewById(R.id.name);
        email = findViewById(R.id.email);



        add = findViewById(R.id.add);
        read = findViewById(R.id.read);
        clear = findViewById(R.id.clear);

        add.setOnClickListener(this);
        read.setOnClickListener(this);
        clear.setOnClickListener(this);

        dbHelper = new DataBaseHelper(this);

        slidingBuilder = new SlidingRootNavBuilder(this)
                .withMenuLayout(R.layout.activity)
                .withToolbarMenuToggle(toolbar)
                .inject();

        navigationView = findViewById(R.id.menu);
        navigationView.setNavigationItemSelectedListener(this);

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();

        String name_str = name.getText().toString();
        String email_str = email.getText().toString();

        SQLiteDatabase database = dbHelper.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        switch (id) {
            case R.id.add:
                contentValues.put(DataBaseHelper.KEY_TITLE, name_str);
                contentValues.put(DataBaseHelper.KEY_TEXT, email_str);

                database.insert(DataBaseHelper.TABLE_CONTACTS, null, contentValues);
                break;

            case R.id.read:

                Cursor cursor = database.query(DataBaseHelper.TABLE_CONTACTS, null, null, null, null, null, null);
                if (cursor.moveToFirst()) {
                   int titleIndex = cursor.getColumnIndex(DataBaseHelper.KEY_TITLE);
                   int contentIndex = cursor.getColumnIndex(DataBaseHelper.KEY_TEXT);
                   int inIndex = cursor.getColumnIndex(DataBaseHelper.KEY_ID);

                   while (cursor.moveToNext()){

                       Log.d("MyDatabase", "ID = " + cursor.getInt(inIndex) +
                               ", Title = " + cursor.getString(titleIndex) + ", Content = " + cursor.getString(contentIndex));
                   }
                }
                fkredit = new FragmentKredit();
                FragmentTransaction ftrans = getSupportFragmentManager().beginTransaction().replace(R.id.container, fkredit);
                ftrans.commit();
                cursor.close();
                break;
            case R.id.clear:
                database.delete(DataBaseHelper.TABLE_CONTACTS, null, null);
                break;

        }
        dbHelper.close();
    }

    @Override
    public void onBackPressed() {
        if (fkredit.isAdded()){
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction().remove(fkredit);
            fragmentTransaction.commit();
            fkredit.onDetach();
        } else {
            super.onBackPressed();
        }


    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        SQLiteDatabase database = dbHelper.getWritableDatabase();
        int id = item.getItemId();

        if (id == R.id.my_kredit){
            Cursor cursor = database.query(DataBaseHelper.TABLE_CONTACTS, null, null, null, null, null, null);
            if (cursor.moveToFirst()) {
                int titleIndex = cursor.getColumnIndex(DataBaseHelper.KEY_TITLE);
                int contentIndex = cursor.getColumnIndex(DataBaseHelper.KEY_TEXT);
                int inIndex = cursor.getColumnIndex(DataBaseHelper.KEY_ID);

                while (cursor.moveToNext()){

                    Log.d("MyDatabase", "ID = " + cursor.getInt(inIndex) +
                            ", Title = " + cursor.getString(titleIndex) + ", Content = " + cursor.getString(contentIndex));
                }
            }
            fkredit = new FragmentKredit();
            FragmentTransaction ftrans = getSupportFragmentManager().beginTransaction().replace(R.id.container, fkredit);
            ftrans.commit();
            cursor.close();
        }
        slidingBuilder.closeMenu();

        return true;
    }
}
